import { Action, createReducer, on } from '@ngrx/store';
import * as TodoActions from './todo.actions';

import { FILTER_MODES } from './../constants/filter-modes';
import { ITodo } from '../interfaces/ITodo';

export type ITodosState = {
  filterMode?: FILTER_MODES,
  todos: ITodo[]
}

export const initialState: ITodosState = {
  filterMode: 'All',
  todos: [],
};

const reducer = createReducer(
  initialState,
  on(TodoActions.addTodo, (state, { todo }) => ({ ...state, todos: [...state.todos, todo] })),
  on(TodoActions.updateTodo, (state, { todo }) => {
    let todoList = state.todos;
    todoList.forEach((t) => {
      if (t.id === todo.id) {
        t.text = todo.text;
      }
    })
    return {
      ...state,
      todos: todoList
    }
  }),
  on(TodoActions.removeTodo, (state, { index }) => {
    console.log('index', index)
    const updatedTodos = [...state.todos];
    updatedTodos.splice(index, 1);
    return {
      ...state,
      todos: updatedTodos,
    };
  }),
  on(TodoActions.changeFilterMode, (state, { mode }) => ({
    ...state,
    filterMode: mode,
  })),
  on(TodoActions.clearCompleted, (state) => ({
    ...state,
    todos: [...state.todos.filter(todo => !todo.completed)],
  })),
);

export function todosReducer(state: ITodosState, action: Action) {
  return reducer(state, action);
}
