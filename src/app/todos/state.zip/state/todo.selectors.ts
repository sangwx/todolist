import { createSelector, createFeatureSelector } from '@ngrx/store';
import { FILTER_MODES } from '../constants/filter-modes';
import { ITodo } from '../interfaces';
import * as todosState from './todos.reducer';

import { ITodosState } from "./todos.reducer";

const selectTodoState = (state: ITodosState) => state;

export const todosSelector = createFeatureSelector<todosState.ITodosState>('todos');

export const getFilter = createSelector(selectTodoState, (state: ITodosState) => state.filterMode);
export const getAllTodo = createSelector(selectTodoState, (state: ITodosState) => {
    console.log('state.todos type: ', typeof state.todos)
    console.log('state.todos: ', state.todos)
    return state.todos
});
export const getActiveTodo = createSelector(selectTodoState, (state: ITodosState) => { return state.todos.filter(t => !t.completed) });
export const getCompletedTodo = createSelector(selectTodoState, (state: ITodosState) => { return state.todos.filter(t => t.completed) });

export const getTodoCount = createSelector(getActiveTodo, (todos: ITodo[]) => todos.length);


// export const allTodos = createSelector(
//   todosSelector,
//   todosState.todos,
// );

