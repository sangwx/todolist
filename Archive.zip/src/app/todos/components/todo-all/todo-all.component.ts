import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FILTER_MODES } from '@app/todos/constants/filter-modes';
import { getRandomNum } from '@app/todos/helpers/number';
import { ITodo } from '@app/todos/interfaces';
import { TodoStoreModule } from '@app/todos/state';
import { addTodo } from '@app/todos/state/todo.actions';
import { getTodoCount, getFilter, getAllTodo } from '@app/todos/state/todo.selectors';
import { select, Store } from '@ngrx/store';
 
@Component({
  selector: 'app-todo-all',
  templateUrl: './todo-all.component.html',
  styleUrls: ['./todo-all.component.scss'],
})
export class TodoAllComponent implements OnInit {

  isShow: boolean = false;
  
  todoCount: number;
  mode: FILTER_MODES;

  constructor(
    private store$: Store<TodoStoreModule>,
    private route: ActivatedRoute
  ) { 
    this.store$.pipe(select(getAllTodo)).subscribe(todoList => this.watchAllTodo(todoList));
    this.store$.pipe(select(getTodoCount)).subscribe(count => this.watchCount(count));
    this.store$.pipe(select(getFilter)).subscribe(mode => this.watchMode(mode));
  }

  ngOnInit(): void {

  }

  private watchAllTodo(todoList) {
    let len = todoList.todos.length;
    // console.log(11, todoList, len)
    this.isShow = len === 0 ? true : false;
  }

  private watchCount(count: number) {
    this.todoCount = count;
  }

  private watchMode(mode: FILTER_MODES) {
    console.log(mode)
    this.mode = mode;
  }

  onSaveTodo(text: string) {
    const todo: ITodo = {
      id: getRandomNum(),
      text,
      completed: false
    }
    this.store$.dispatch(addTodo({todo}))
  }

}
