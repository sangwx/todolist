import { Component, Input, OnInit } from '@angular/core';
import { FILTER_MODES } from '@app/todos/constants/filter-modes';
import { Router } from "@angular/router";

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

  id = 1;

  currentFilter: FILTER_MODES = "All";
  hasCompleted: boolean = true;

  @Input() todoCount: number;
  @Input() mode: FILTER_MODES;

  constructor(
    public router: Router
  ) { }

  ngOnInit(): void {
  }


}
