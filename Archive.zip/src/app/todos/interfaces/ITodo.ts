export type ITodo = {
  id?: number,
  text: string,
  completed?: boolean
}
