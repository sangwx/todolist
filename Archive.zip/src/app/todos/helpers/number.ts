export function getRandomNum(): number {
    return Math.floor(Math.random() * 10000);
}